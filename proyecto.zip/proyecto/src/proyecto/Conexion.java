
package proyecto;

import java.sql.*;

public class Conexion {
    Connection con;
    
    public Conexion(){
        try{
        con=DriverManager.getConnection("", "root", "admin");
        }catch(Exception e){
            System.out.print("No se pudo establecer conexion con la base de datos. Error:"+e);
        }
    }
    public Connection getConnection(){
        return con ;
    }
}
