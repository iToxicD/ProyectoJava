/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto;

import java.sql.*;

/**
 *
 * @author ruben
 */
public class Conexion {
    Connection con;
    
    public Conexion(){
        try{
        con=DriverManager.getConnection("jdbc:mariadb://localhost:3306/Spotify", "root", "admin");
        }catch(Exception e){
            System.out.print("No se pudo establecer conexion con la base de datos. Error:"+e);
        }
    }
    public Connection getConnection(){
        return con ;
    }
}
